# Gbekor SHS Learning Portal

**Finishing the Job Right — A Blended Word-Processing Skills Intervention and Learning Portal for Gbekor Senior High School**

A front-end prototype of a browser-based learning portal built for the Gbekor Senior High School ICT/Computing Department (Adaklu, Volta Region, Ghana). It demonstrates the intended student and teacher experience for a blended Word Processing Essentials course, alongside the school's classroom-based lesson (projector + printed job aids + paired practice).

## What's inside

A single self-contained file — `index.html` — with no build step and no external dependencies beyond a Google Fonts import. Open it directly in any browser.

## Features

- **Student view** — dashboard, course progress, three self-check quizzes (Knowledge, Saving, Table & Printing), an interactive "Ama's Assignment" decision scenario, and a recent-activity record.
- **Teacher view** — class progress, at-risk flagging, and a student monitoring table.
- Quiz results are graded instantly and reflected live in the dashboard stats and activity log for the current session.

## Running it locally

No installation needed — just open `index.html` in a browser, or serve it with any static file server:

```bash
npx serve .
# or
python3 -m http.server 8000
```

## Deploying it (get a public link)

This is a static site, so any static host works. Two of the simplest options:

**Netlify Drop** (no account, no git needed)
1. Go to <https://app.netlify.com/drop>
2. Drag this folder (or just `index.html`) onto the page
3. You'll get a live public URL immediately

**GitHub Pages**
1. Push this repository to GitHub
2. In the repo settings, enable **Pages** → deploy from the `main` branch, root folder
3. Your site will be live at `https://<username>.github.io/<repo-name>/`

## Status

This is a **front-end prototype**, not a production LMS. There is no backend, no real authentication, and no persistent database — sign-in accepts any input, and quiz records exist only for the current browser session. A production deployment (real student/teacher accounts, centrally stored grades, attendance, reporting) would require a full LMS platform such as Moodle, consistent with the offline-first design rationale described in the accompanying project report.

## Author

Dennis Kofi Adzabe — Gbekor Senior High School / University of Cape Coast, Educational Technology programme.
